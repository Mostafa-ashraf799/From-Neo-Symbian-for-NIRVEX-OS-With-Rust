/*
* Copyright (c) 2009 Nokia Corporation and/or its subsidiary(-ies).
* All rights reserved.
* This component and the accompanying materials are made available
* under the terms of the License "Eclipse Public License v1.0"
* which accompanies this distribution, and is available
* at the URL "http://www.eclipse.org/legal/epl-v10.html".
*
* Initial Contributors:
* Nokia Corporation - initial contribution.
*
* Contributors:
*
* Description:
*
*/
#ifndef __INDWSDDLL_H__
#define __INDWSDDLL_H__

#include <e32base.h>

IMPORT_C TInt IndWsdFuncX();
IMPORT_C TInt IndWsdFuncY();

#endif // __INDWSDDLL_H__
